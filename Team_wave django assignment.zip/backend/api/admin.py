from django.contrib import admin

# Register your models here.
from api.models import Questions
admin.site.register(Questions)